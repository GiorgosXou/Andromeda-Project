package com.google.devtools.simple.runtime.android;

public class FilesImpl {

}
