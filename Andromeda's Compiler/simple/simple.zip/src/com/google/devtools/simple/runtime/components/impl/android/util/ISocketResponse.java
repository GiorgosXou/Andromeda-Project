package com.google.devtools.simple.runtime.components.impl.android.util;
public interface ISocketResponse
{
	public abstract void onSocketResponse(String txt);
}