package com.google.devtools.simple.runtime;

public class FilesFunctions {

}
