/*
 * Copyright 2009 Google Inc.
 * Lu Chengwei 2013, VB4A
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.devtools.simple.runtime.components.impl.android;

import com.google.devtools.simple.runtime.android.ApplicationImpl;
import com.google.devtools.simple.runtime.components.ComponentContainer;
import com.google.devtools.simple.runtime.components.Phone;
import com.google.devtools.simple.runtime.components.impl.ComponentImpl;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Vibrator;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.telephony.gsm.SmsManager; 
import android.telephony.TelephonyManager;  
import android.widget.Toast; 

/*
import android.location.Location;   
import android.location.LocationListener;   
import android.location.LocationManager;   
*/
import java.util.ArrayList; 
import java.io.BufferedReader;  
import java.io.BufferedWriter;  
import java.io.InputStreamReader;  
import java.io.OutputStreamWriter;  
import java.io.PrintWriter;  
import java.net.Socket;  
import java.io.IOException;  
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
/**
 * Implementation of phone related functions.
 * 
 * @author Herbert Czymontek
 */
public final class PhoneImpl extends ComponentImpl implements Phone {

  private final Vibrator vibrator;

  /**
   * Creates a new Phone component.
   *
   * @param container  container which will hold the component (must not be
   *                   {@code null}, for non-visible component, like this one
   *                   must be the form)
   */
  public PhoneImpl(ComponentContainer container) {
    super(container);

    vibrator = (Vibrator) ApplicationImpl.getContext().getSystemService(Context.VIBRATOR_SERVICE);
  }

  // Phone implementation

  @Override
  public boolean Available() {
    return true;
  }

  @Override
  public void Call(String phoneNumber) {
    if (null != phoneNumber && phoneNumber.length() > 0) {
      ApplicationImpl.getContext().startActivity(new Intent(Intent.ACTION_CALL,
          Uri.parse("tel:" + phoneNumber)));
    }
  }

  @Override
  public void SendSMS(String phoneNumber,String text,String warnings) {
	    
		if (null != phoneNumber && phoneNumber.length() > 0) {
			SmsManager smsManager = SmsManager.getDefault(); 
			ArrayList<String> msgs=smsManager.divideMessage(text);
			smsManager.sendMultipartTextMessage(phoneNumber, null, msgs, null, null);
			if (warnings=="")
			{
				warnings="SMS has been sent to "+phoneNumber+".";
			}
			Toast.makeText(ApplicationImpl.getContext(), warnings,Toast.LENGTH_SHORT).show();
    }
  }


  @Override
  public void SendMail(String Address, String mailtitle, String mailtext) {
	    Intent data=new Intent(Intent.ACTION_SENDTO);  
        data.setData(Uri.parse("mailto:"+Address));  
        data.putExtra(Intent.EXTRA_SUBJECT, mailtitle);  
        data.putExtra(Intent.EXTRA_TEXT, mailtext);  
        ApplicationImpl.getContext().startActivity(data); 
  }

  public static byte[] readFromInput(InputStream inStream) throws Exception {
    ByteArrayOutputStream outStream = new ByteArrayOutputStream();
    byte[] buffer = new byte[1024];
    int len = 0;
    while ((len = inStream.read(buffer)) != -1) {
      outStream.write(buffer, 0, len);
    }
    inStream.close();
    return outStream.toByteArray();
  }
  
  @Override
  public String VB4APost(String url, String params, int Ctimeout, int Rtimeout,String charset) {
    String str = "";
    try {
      URL url2 = new URL(url);
      HttpURLConnection conn = (HttpURLConnection)url2.openConnection();
      conn.setRequestMethod("POST");
      conn.setConnectTimeout(Ctimeout);
      conn.setReadTimeout(Rtimeout);
      conn.setDoOutput(true);
      byte[] bypes = params.toString().getBytes();
      conn.getOutputStream().write(bypes);
      InputStream inStream = conn.getInputStream();
      byte[] data = readFromInput(inStream);
      str = new String(data, charset);
    } catch (Exception e) {
      return "empty";
    }
    return str;
  }
  
  @Override
  public String VB4AGet(String url,String codec) {
	return GetURL(url,codec);
  }

  @Override
  public String GetURL(String url,String codec) {
	URL url2;
	int responsecode;
	HttpURLConnection urlConnection=null;
    BufferedReader reader;
    String line;
	String urlCode;
	urlCode="";
	try{
            //����һ��URL����Ҫ��ȡԴ�������ҳ��ַΪ��http://www.sina.com.cn
            url2=new URL(url);
            //��URL
            urlConnection = (HttpURLConnection)url2.openConnection();
            //��ȡ��������Ӧ����
            responsecode=urlConnection.getResponseCode();
            if(responsecode==200){
                //�õ������������������ҳ������ 
                reader=new BufferedReader(new InputStreamReader(urlConnection.getInputStream(),codec));
                while((line=reader.readLine())!=null){
                    urlCode=urlCode+line+"\n";
                }
				
            }
            else{
                urlCode="Respond:"+responsecode;
            }
        }
        catch(Exception e){
            urlCode="Error!";
        }
		urlConnection.disconnect();
		return urlCode;
    }

	

/*
  public String VB4APost(String pathUrl, String data) {
	try
	{
		URL url = new URL(pathURL);
		HttpURLConnection httpConn=(HttpURLConnection)url.openConnection();
		 httpConn.setDoOutput(true);//ʹ�� URL ���ӽ������
		 httpConn.setDoInput(true);//ʹ�� URL ���ӽ�������
		 httpConn.setUseCaches(false);//���Ի���
		 httpConn.setRequestMethod("POST");//����URL���󷽷�
		 String requestString = data;
     //������������
    //��������ֽ����ݣ������������ı��룬���������������˴����������ı���һ��
          byte[] requestStringBytes = requestString.getBytes(ENCODING_UTF_8);
          httpConn.setRequestProperty("Content-length", "" + requestStringBytes.length);
          httpConn.setRequestProperty("Content-Type", "application/octet-stream");
          httpConn.setRequestProperty("Connection", "Keep-Alive");// ά�ֳ�����
          httpConn.setRequestProperty("Charset", "UTF-8");
          //
          String name=URLEncoder.encode("������","utf-8");
          httpConn.setRequestProperty("NAME", name);
          
          //�������������д������
          OutputStream outputStream = httpConn.getOutputStream();
          outputStream.write(requestStringBytes);
          outputStream.close();
         //�����Ӧ״̬
          int responseCode = httpConn.getResponseCode();
          if(HttpURLConnection.HTTP_OK == responseCode){//���ӳɹ�
           
           //����ȷ��Ӧʱ��������
           StringBuffer sb = new StringBuffer();
              String readLine;
              BufferedReader responseReader;
             //������Ӧ�����������������Ӧ������ı���һ��
              responseReader = new BufferedReader(new InputStreamReader(httpConn.getInputStream(), ENCODING_UTF_8));
              while ((readLine = responseReader.readLine()) != null) {
               sb.append(readLine).append("/n");
              }
              responseReader.close();
              return sb.toString();

	}
	catch (Exception ex)
	{
		ex.printStackTrace();
	}



  }
*/

  @Override
  public String SocketSend(String ip,int port,String data) {
	Socket s=null;
	BufferedReader din = null;  
    PrintWriter dout = null;  
	String str="";
	String str2="";
	try{
		s=new Socket(ip,port);
		s.setSoTimeout(5000);
		din = new BufferedReader(new InputStreamReader(s.getInputStream()));  
        dout = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream()))); 
		dout.println(data);
		dout.flush();
		while ((str = din.readLine()) != null) {
        str2=str2+str+"\n";
		}

		} catch (Exception e) {  
            //e.printStackTrace(); 
			return "Null";
        } finally {  
            try {  
                din.close();  
                dout.close();  
                s.close();  
            } catch (IOException e) {  
                //e.printStackTrace();  
				return "Null";
            }  
        }  
		return str2;
  }

  @Override
  public void JumpURL(String url) {
	Uri uri = Uri.parse(url);  
	Intent it = new Intent(Intent.ACTION_VIEW, uri);  
    ApplicationImpl.getContext().startActivity(it);
  }

  @Override
  public void Vibrate(int duration) {
    vibrator.vibrate(duration);
  }
/*
  @Override
  public String GetIMEI() {
	TelephonyManager tele = (TelephonyManager) ApplicationImpl.getContext().getSystemService(Context.TELEPHONY_SERVICE);
	return tele.getDeviceId();
  }
 */
}
